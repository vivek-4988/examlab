package com.example.sample.service.data


class APIModel : ArrayList<APIModelItem>()