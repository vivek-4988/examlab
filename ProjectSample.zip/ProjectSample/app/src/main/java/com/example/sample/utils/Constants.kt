package com.example.sample.utils

/*
*
* File to enter any constant variable
* */

object ApiKeys {
    const val noofpage: String = "10"
}

object DateTimePattern {
    const val PATTERN_ABR_MONTH_NAME_WITH_DATE_AND_YEAR = "MMM dd,yyyy"
}

object IntentKeys {
    const val htmlDetails = "htmlDetails"
}